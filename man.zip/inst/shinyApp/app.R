shinyAppDemo::launchApp()
